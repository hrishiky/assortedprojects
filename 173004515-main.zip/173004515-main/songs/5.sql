SELECT AVG(energy) FROM songs;
